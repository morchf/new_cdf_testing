#!/bin/bash

# TODO:  add generating an auth token, and passing the token as Authroization header, once IAM auth is in place

. ./config.bash
#######
#
# Notes: Order of creation is extremely important. Devices have to exist before a group
# can claim them via an "in" relationship. Translation of this to actions means:
#       1. Create the vehicle and traffic first
#       2. Create the agency second. Part of creating the agency include defining the
#          relationship with vehicle and traffic. The relationship is "in" meaning
#          traffic and vehicles are in an agency. The relationship "owns" is just a
#          identifier of choice that best describes the relation; it can be any string.
#          In this case an "agency" "owns" "vehicle" and "owns" "traffic".
#          These relationship show up with listing group/device templates/instances.
#       3. Lastly, map agency to root.


########## Create device template skeletons without dependencies ####
curl -X POST \
  "$BASE_URL/templates/device/vehicle" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" \
  -d '{"properties": {},"required": []}'

curl -X POST \
  "$BASE_URL/templates/device/traffic" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" \
  -d '{"properties": {},"required": []}'

########## Updating device templates without depencies. #####
VEHICLE_JSON=$(< vehicle_template.json)
curl -X PATCH \
  "$BASE_URL/templates/device/vehicle" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" \
  -d "$VEHICLE_JSON"

TRAFFIC_JSON=$(< traffic_template.json)
curl -X PATCH \
  "$BASE_URL/templates/device/traffic" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" \
  -d "$TRAFFIC_JSON"

########## Publishing device templates so they can be used ####
curl -X PUT \
  "$BASE_URL/templates/device/vehicle/publish" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE"

curl -X PUT \
  "$BASE_URL/templates/device/traffic/publish" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE"


########## Agency Template: crete skeleton, add JSON, then publish ####
########## relationship to vehicle and traffic defined in this JSON ###
echo 'Creating (skeleton) templates ...'
curl -X POST \
  "$BASE_URL/templates/group/agency" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" \
  -d '{"properties": {},"required": []}'
AGENCY_JSON=$(< agency_template.json)
curl -X PATCH \
  "$BASE_URL/templates/group/agency" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" \
  -d "$AGENCY_JSON"
echo 'Publishing templates ...'
curl -X PUT \
  "$BASE_URL/templates/group/agency/publish" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE"

