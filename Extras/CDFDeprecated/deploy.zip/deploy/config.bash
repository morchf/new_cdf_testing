#!/bin/bash

BASE_URL=https://8wmlwv2gge.execute-api.us-west-2.amazonaws.com/Stage
ACCEPT='Accept: application/vnd.aws-cdf-v2.0+json'
CONTENT_TYPE='Content-Type: application/vnd.aws-cdf-v2.0+json'
