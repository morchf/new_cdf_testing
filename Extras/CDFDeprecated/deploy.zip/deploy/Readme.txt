Description of the files:
- cdf_delete_stacks.py:
    - Delete CDF stacks
    - list the subnets for the cdf-network-stage stack that are the source
      of the cdf-network-stage not deleting. Manually delete these subnets
      then run cdf_delete_stacks.py again.
- config.bash
    - configuraiton for *.bash scripts
    - change the URL to the asset library URL
- create_template.bash
    - create templates
- delete_template.bash
    - delete templates
- list_templates.bash
    - list templates
