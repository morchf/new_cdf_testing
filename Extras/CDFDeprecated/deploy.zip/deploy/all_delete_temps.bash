#!/bin/bash

  # "$BASE_URL/groups/%2fagency?name=$TEMPLATE_NAME" \ works for deleting an instance of an agency
  # "$BASE_URL/templates/$TEMPLATE_TYPE?/TEMPLATE_NAME" \ worked for device vehicle, not for agency
  # "$BASE_URL/templates/%2f$TEMPLATE_TYPE/$TEMPLATE_NAME" \

. ./config.bash


TEMPLATE_NAME='vehicle'    # agency, vehicle, traffic
TEMPLATE_TYPE='device'   # group, device
echo ""
echo "Delete template $TEMPLATE_NAME in $TEMPLATE_TYPE ..."
curl -X DELETE \
  "$BASE_URL/templates/$TEMPLATE_TYPE/$TEMPLATE_NAME" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" 


TEMPLATE_NAME='traffic'    # agency, vehicle, traffic
TEMPLATE_TYPE='device'   # group, device
echo ""
echo "Delete template $TEMPLATE_NAME in $TEMPLATE_TYPE ..."
curl -X DELETE \
  "$BASE_URL/templates/$TEMPLATE_TYPE/$TEMPLATE_NAME" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" 

TEMPLATE_NAME='agency'    # agency, vehicle, traffic
TEMPLATE_TYPE='group'   # group, device
echo ""
echo "Delete template $TEMPLATE_NAME in $TEMPLATE_TYPE ..."
curl -X DELETE \
  "$BASE_URL/templates/$TEMPLATE_TYPE/$TEMPLATE_NAME" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" 
