#!/bin/bash

# TODO:  add generating an auth token, and passing the token as Authroization header, once IAM auth is in place

. ./config.bash

########## Updating device templates without depencies. #####
VEHICLE_JSON=$(< vehicle_template.json)
curl -X PATCH \
  "$BASE_URL/templates/device/vehicle" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" \
  -d "$VEHICLE_JSON"

########## Publishing device templates so they can be used ####
curl -X PUT \
  "$BASE_URL/templates/device/vehicle/publish" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE"

AGENCY_JSON=$(< agency_template.json)
curl -X PATCH \
  "$BASE_URL/templates/group/agency" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" \
  -d "$AGENCY_JSON"

########## Publishing device templates so they can be used ####
curl -X PUT \
  "$BASE_URL/templates/group/agency/publish" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE"
