#!/bin/bash

. ./config.bash

echo '--- 1. Get agency templates returns all agency but only ask for one - works but not as expected'
curl -X GET \
  "$BASE_URL/templates/group?templateId=root" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" 
echo ''

echo '--- 2. Get agency templates returns all agency but only ask for one - works but not as expected'
curl -X GET \
  "$BASE_URL/templates/group?templateId=agency" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" 
echo ''

echo '--- 3. Get draft group templates - works '
curl -X GET \
  "$BASE_URL/templates/group?status=draft" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" 
echo ''

echo '--- 4. Get published group templates - works '
curl -X GET \
  "$BASE_URL/templates/group?status=published" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" 
echo ''

echo '--- 5. Get draft device templates - works '
curl -X GET \
  "$BASE_URL/templates/device?status=draft" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" 
echo ''

echo '--- 6. Get published device templates - works '
curl -X GET \
  "$BASE_URL/templates/device?status=published" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" 
echo ''

