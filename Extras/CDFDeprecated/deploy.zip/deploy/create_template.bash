#!/bin/bash

. ./config.bash

TEMPLATE_NAME='agency'  # ga, agency, vehicle, traffic
TEMPLATE_TYPE='group'   # group, device
TEMPLATE_JSON=$(< ${TEMPLATE_NAME}_template.json)
echo $TEMPLATE_JSON

########## Create template skeletons without dependencies ####
echo "Create skeleton template $TEMPLATE_NAME in $TEMPLATE_TYPE ..."
curl -X POST \
  "$BASE_URL/templates/$TEMPLATE_TYPE/$TEMPLATE_NAME" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" \
  -d '{"properties": {},"required": []}'

########## Updating templates with depencies now that they exist. #####
echo "Update template $TEMPLATE_NAME in $TEMPLATE_TYPE ..."
curl -X PATCH \
  "$BASE_URL/templates/$TEMPLATE_TYPE/$TEMPLATE_NAME" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE" \
  -d "$TEMPLATE_JSON"

########## Publishing templates so they can be used ####
echo "Publish template $TEMPLATE_NAME in $TEMPLATE_TYPE ..."
curl -X PUT \
  "$BASE_URL/templates/$TEMPLATE_TYPE/$TEMPLATE_NAME/publish" \
  -H "$ACCEPT" \
  -H "$CONTENT_TYPE"
